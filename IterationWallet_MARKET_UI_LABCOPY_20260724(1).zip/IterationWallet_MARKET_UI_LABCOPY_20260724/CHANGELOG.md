# Changelog

## 2.5.0a5 — Quarantine pipeline access and retry hardening

- Tightened quarantine and transition-evidence directories to owner-only POSIX permissions.
- Proved the quarantine compartment contains payload bytes only; operational state remains in Wallet and canonical BlackBox evidence.
- Refused completed-object re-staging and duplicate quarantine publication.
- Fixed unchanged static-inspection retries that crossed a timestamp boundary and falsely conflicted with the write-once report identity.
- Added donor conformance analysis without importing destructive delete or automatic-install behavior.

## 2.5.0a5 — Standalone BlackBox dependency and host-owned adapters

- Made BlackBox `0.6.0a2` the sole installed owner of `blackbox_plugin`.
- Moved `iteration_wallet_blackbox` into the Wallet distribution.
- Removed the active embedded BlackBox source path from Wallet; preserved it under history.
- Added the neutral `bbx1-client/1` contract and local client implementation.
- Routed Wallet's production evidence path through its durable adapter/outbox.
- Distinguished retryable unavailability, permanent rejection, and acknowledgement-persistence failure.
- Added an Oubliette-owned observation adapter with explicit no-custody/no-authority enforcement.
- Defaulted Oubliette safely to disabled and made demos opt into transaction mode explicitly.
- Sealed authority journals, strengthened no-clobber custody publication, bounded archive claims, and hardened outbox writes in the preceding repair pass.
- Added `iw doctor` for version, client-schema, and installed-package ownership verification.
