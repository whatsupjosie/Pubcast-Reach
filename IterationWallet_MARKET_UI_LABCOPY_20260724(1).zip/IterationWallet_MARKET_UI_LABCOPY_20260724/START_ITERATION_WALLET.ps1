$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Test-Path '.venv\Scripts\python.exe')) { py -3 -m venv .venv }
& '.venv\Scripts\python.exe' -m pip install --disable-pip-version-check -q -e '.\blackbox_source' -e '.'
$env:IW_HOME = Join-Path $PSScriptRoot 'wallet_home'
$env:IW_OUBLIETTE_MODE = 'disabled'
& '.venv\Scripts\python.exe' app.py
