#!/usr/bin/env python3
"""
Iteration Wallet — Launcher
============================
Starts the FastAPI server and opens the UI in the default browser.

Usage:
    python app.py            # start on default port 7432
    python app.py --port 8080
    python app.py --no-browser
"""

import argparse
import logging
import sys
import threading
import time
import webbrowser
from pathlib import Path

import uvicorn

# Add the package directory to path so imports work from this file
sys.path.insert(0, str(Path(__file__).parent))

from iteration_wallet.server import app  # noqa: E402 — after sys.path patch

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("iw.launcher")


def _open_browser(url: str, delay: float = 1.2) -> None:
    """Open the UI after a short delay to let the server start."""
    time.sleep(delay)
    webbrowser.open(url)


def main() -> None:
    parser = argparse.ArgumentParser(description="Iteration Wallet")
    parser.add_argument("--port", type=int, default=7432, help="Port to listen on (default: 7432)")
    parser.add_argument("--host", default="127.0.0.1", help="Host to bind (default: 127.0.0.1)")
    parser.add_argument("--no-browser", action="store_true", help="Don't open browser automatically")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload (dev mode)")
    args = parser.parse_args()

    url = f"http://{args.host}:{args.port}"

    print()
    print("  ⚿  Iteration Wallet — Rear View Foresight")
    print(f"     Vault UI  →  {url}")
    print(f"     API docs  →  {url}/docs")
    print()

    if not args.no_browser:
        t = threading.Thread(target=_open_browser, args=(url,), daemon=True)
        t.start()

    uvicorn.run(
        "iteration_wallet.server:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
        log_level="warning",  # suppress uvicorn noise; our logs handle it
    )


if __name__ == "__main__":
    main()
