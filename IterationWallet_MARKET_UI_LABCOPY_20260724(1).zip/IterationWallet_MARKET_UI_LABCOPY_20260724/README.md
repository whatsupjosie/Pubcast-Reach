# Iteration Wallet 2.5.0a5

Iteration Wallet is a local-first custody tool for AI-assisted project work. It keeps project generations in explicit states, requires Human Intent for protected transitions, records canonical facts through standalone BlackBox, and keeps Oubliette static-only and optional.

## Current proven workflow

- Create/open a Wallet project.
- Add Raw Source and Candidate files.
- Promote Candidate to Prime through Human Intent.
- Export an HMAC-authenticated LabCopy.
- Re-enter changed LabCopy material as a new Candidate with `derived_from_hash`.
- Re-enter missing or invalid manifest material as unlinked Raw Source.
- Treat identical LabCopy return as a no-op.
- Inspect statically with Oubliette.
- Quarantine through Wallet-owned Human Intent without deletion.
- Verify BlackBox and custody state.

## CLI first

The CLI is the official alpha surface. Start with:

```bash
iw doctor
iw serve --root ./wallet-data
```

Then use `iw --help` for commands. The browser UI/server exists, but browser automation is not part of the proven alpha claim.

## Known boundaries

Remove, restore, and release remain deliberately unavailable. Runtime Continuity is implemented and tested as a library. Windows execution is not claimed from Linux tests.
