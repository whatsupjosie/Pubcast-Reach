# Open Gates After 2.4.0a1

The strongest reason this Candidate could still be overstated is that the bounded Oubliette crossing is not the complete external-laboratory and generation-authority story.

## Next engineering seam

Implement a Wallet-owned LabCopy export/result-envelope transaction without granting execution authority to Oubliette:

1. export a traceable copy outside custody;
2. bind parent generation, export scope, policy, hash manifest, and operation ID;
3. let external tools operate independently outside Wallet;
4. accept a bounded result envelope and returned bytes;
5. preserve results as external assertions;
6. admit returned material only as Raw Source or Candidate;
7. compare lineage and Runtime Continuity divergence;
8. never infer trust, Prime status, or safety from an external result.

## Other open gates

- BBX-007 manual durable-outbox certification;
- complete append-only generation graph;
- one-owner-per-authority formal review;
- Windows execution and failure campaigns;
- whole-application disk-full campaign;
- PubCast lifecycle bridge and degraded mode;
- independent external witnessing and cross-language verification;
- final contest repository, submission description, video, and timing rehearsal.
