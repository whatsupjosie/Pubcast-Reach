# Installation — Iteration Wallet 2.5.0a5

## Normal online install from this release bundle

From a fresh virtual environment, install both product wheels. Pip will resolve third-party dependencies such as FastAPI, Uvicorn, Pydantic, and Requests from your configured package index.

```powershell
python -m pip install .\bbx1_iteration_wallet_plugin-0.6.0a2-py3-none-any.whl .\iteration_wallet-2.5.0a5-py3-none-any.whl
```

Then run:

```powershell
iw doctor
iw serve --root .\wallet-data
```

## Offline install

This release bundle contains the Wallet and BlackBox wheels, but not a full third-party dependency wheelhouse. Offline installation requires pre-downloaded wheels for the dependencies declared in `setup.py`: FastAPI, Uvicorn, Pydantic, Requests, and their transitive dependencies.

## Legacy overlapping alpha repair

If a machine previously installed the older alpha pair whose wheels shared package ownership, use:

```powershell
python tools\migrate_alpha_install.py --wallet-wheel .\iteration_wallet-2.5.0a5-py3-none-any.whl --blackbox-wheel .\bbx1_iteration_wallet_plugin-0.6.0a2-py3-none-any.whl
```

The tool removes both old distributions first, installs both new wheels, then verifies versions, client schema, and sole package ownership.
