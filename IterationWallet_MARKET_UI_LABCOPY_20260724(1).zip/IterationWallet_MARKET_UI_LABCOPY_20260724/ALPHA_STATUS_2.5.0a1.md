# Integrated Alpha Status — 2.5.0a5

## Required core

- Iteration Wallet custody and protected-transition coordinators
- BlackBox `0.6.0a2`
- Wallet-owned BlackBox adapter and durable outbox

## Optional component

Oubliette is capability-gated:

- `disabled`: unavailable; core remains healthy.
- `inspect`: static observation and protective request only.
- `transaction`: tested Wallet-owned quarantine and Candidate-only return.

## Release claims

This alpha proves local consistency, deterministic package ownership, exact proposal-scoped Human Intent, restart-aware custody transactions, static-only Oubliette inspection, and canonical BlackBox recording.

It does not claim independent witnessing, malware certainty, production hardening, complete Windows certification, or complete external laboratory authority.
