# Five-Minute Integrated Demo — Wallet + BlackBox + Optional Oubliette

## Story

1. Start with `IW_OUBLIETTE_MODE=disabled`; show Wallet and BlackBox core healthy.
2. Create a project, section, Candidate, and canonical promotion receipt.
3. Restart a fresh demo root with `IW_OUBLIETTE_MODE=transaction`.
4. Admit unknown material, statically inspect it, and show that a planted execution marker was never created.
5. Quarantine the original through Human Intent; show bytes preserved and BlackBox chain verified.
6. Present a reviewed external derivative. Wallet captures exact bytes as an Intake Capsule.
7. Show capsule ID, manifest hash, coverage, and exact admission proposal.
8. Use proposal-scoped ceremony to admit one deterministic new Candidate.
9. Delete or replace the external source and show the admitted Candidate still matches the preserved capsule, not the path.
10. State limitations: static indicators are not malware verdicts; identity is local continuity; LabCopy and Windows certification remain open.

## Judge-facing sentence

> Rearview Foresight never trusted the filename. It preserved the exact bytes, recorded what was actually known, and required the human to authorize the precise material entering the project.
