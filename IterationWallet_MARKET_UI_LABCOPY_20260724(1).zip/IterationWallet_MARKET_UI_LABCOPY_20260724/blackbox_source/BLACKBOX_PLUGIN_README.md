# BBX1 Standalone Plugin 0.6.0a2

This distribution installs only `blackbox_plugin`. Host applications must own their adapters and depend on the public `bbx1-client/1` contract.

See `README.md`, `BLACKBOX_CLIENT_CONTRACT_0.6.0a2.md`, and `CANONICAL_CURRENT_STATE.md`.
