# Canonical Current State — BlackBox 0.6.0a2

- Core package owner: `bbx1-iteration-wallet-plugin`
- Active Python package: `blackbox_plugin`
- Client schema: `bbx1-client/1`
- Host adapters in wheel: none
- Wallet package in wheel: none
- Execution capability: none
- Custody authority: none
- Human Intent authority: none

Historical Wallet and PubCast adapter implementations are preserved under `reference_source/` and are not installed.
