# BBX1 0.5.0a3 Build Report

- Status: hardened alpha Candidate; not an independent witness or legal evidence system.
- BBX1 suite: 57 passed, 1 intentional skip.
- Migration: raw-byte preservation, chain re-verification, anchor and import-sequence proof, idempotent resume.
- Outbox: hash-chained, cross-process, semantic idempotency, partial-tail rotation, retry after local acknowledgement interruption.
- Packaging: clean wheel, 27 entries, no tests/cache.
- Official BBX-007 remains OPEN because the locked benchmark treats it as a manual gate; semantic evidence is supplied separately.
