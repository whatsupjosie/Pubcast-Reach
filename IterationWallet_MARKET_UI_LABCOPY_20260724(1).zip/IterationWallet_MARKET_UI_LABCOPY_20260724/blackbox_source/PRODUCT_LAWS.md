# Iteration Wallet / BlackBox Product Laws

These laws are product constraints, not preferences. They apply to the combined generation model and to every adapter, UI, helper, and demo.

1. **No Delete of Custodied or Evidentiary Material** — Use archive, Removed, quarantine, release, superseding generations, and append-only acknowledgements. Cleanup must not erase custody or evidence history.
2. **No Silent Overwrite** — Prime, Candidates, references, snapshots, BlackBox records, receipts, seals, checkpoints, manifests, and custody state transitions are never silently replaced.
3. **No Activation Inside Custody** — Wallet and Oubliette may examine, parse safely, compare, classify, model, and predict from inert material. They may not execute, launch, compile, install, dynamically import, emulate, detonate, patch, repair, or test-run the custodied target.
4. **External Laboratory Separation** — Execution, mutation, fuzzing, break-testing, repair, and active-installation changes occur only on a traceable exported copy outside Wallet and Oubliette.
5. **Candidate-Only Return** — Material returning from outside work enters with new lineage as Raw Source or Candidate. It never returns as the same untouched object, Prime, or trusted Reference.
6. **AI Stays Outside the Yard** — AI may analyze approved summaries and propose actions. AI cannot touch custody, operate Oubliette, mint Human Intent, consume ceremony, open a gate, promote, release, admit a Reference, or enforce quarantine by itself.
7. **Humans Open Trust Gates** — Trust-expanding custody decisions require a valid human session, explicit intent, protected-action scope, ceremony when required, actual operation result, Human Intent receipt, and canonical evidence linkage.
8. **One Owner per Authority** — Wallet owns physical custody and generation state. BlackBox owns canonical evidence. Oubliette owns static findings and risk policy. Gatekeeper owns protected-action authorization. External tools own execution and repair.
9. **BlackBox Witnesses; It Does Not Govern** — BlackBox records host-supplied facts, ordering, provenance, coverage, gaps, checks, results, and receipts. It does not decide trust, motive, guilt, custody, legitimacy, or human intent.
10. **Evidence Failure Is Visible** — No action may be represented as fully witnessed when canonical evidence is unavailable. Trust expansion fails closed. Protective restriction may proceed under the documented emergency-gap policy.
11. **Quarantine Is a Reversible Fence** — Quarantine preserves bytes, restricts promotion/release, records the reason and coverage, and remains reviewable. It is not deletion, punishment, malware certainty, or repair.
12. **Oubliette Is Static Inspection Only** — Oubliette inspects, labels, compares, warns, requests deterministic protective fencing through Wallet, and records findings. It does not execute, repair, move custody independently, or decide trust.
13. **Restore Means Restore-from-Removed** — Wallet may reverse a non-destructive Removed state. Writing trusted or repaired bytes into an active installation is external repair and is never a Wallet restore operation.
14. **Closed Views Are Default-Deny Projections** — Safe views expose only event-specific allowed fields. Unknown event types expose envelope metadata only. Redaction by suspicious key name is not sufficient.
15. **Local Consistency Is Not Independent Authentication** — A locally recomputable digest can reveal inconsistency but cannot independently authenticate itself. Independent claims require a separately controlled authority, key, or Wallet.
16. **Claims Follow Proof** — “Tamper-evident,” “crash-safe,” “human-authorized,” “independent,” and similar claims are limited to the exact properties and platforms demonstrated by tests and artifacts.

## Work standard

This is product work, not practice work. Changes are additive, reviewable, bounded, and backed by preserved artifacts. A green friendly suite cannot override a failed constitutional probe.
