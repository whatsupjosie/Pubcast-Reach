# Open Gates — Iteration Wallet 2.5.0a5 / BlackBox 0.6.0a2

1. Complete Wallet-owned LabCopy export and bounded result-return transactions.
2. Define Bridgewright recipe identity and copy-only transformation evidence.
3. Complete the generation graph and release/reference states.
4. Execute the full workflow on Windows and record platform-specific fault evidence.
5. Run genuine disk-exhaustion and abrupt-power-loss campaigns on disposable environments.
6. Add PubCast and PubPartner adapters in their own host packages.
7. Add independent witnessing without upgrading local consistency claims.
8. Finish the contest-facing guided UI, repository presentation, and demonstration video.
9. Add signed release provenance and external reviewer reproduction.
