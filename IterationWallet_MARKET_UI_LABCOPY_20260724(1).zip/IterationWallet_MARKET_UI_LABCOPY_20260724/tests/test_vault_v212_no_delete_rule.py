import tempfile
from pathlib import Path

import pytest

from iteration_wallet.vault_v21 import VaultEngine, VaultError, NO_DELETE_RULE


def make_file(text: str = "data", suffix: str = ".txt") -> Path:
    handle = tempfile.NamedTemporaryFile(mode="w", suffix=suffix, delete=False)
    handle.write(text)
    handle.flush()
    handle.close()
    return Path(handle.name)


def setup_vault(tmpdir: str):
    vault = VaultEngine(Path(tmpdir))
    project = vault.create_project("App")
    section = vault.create_section(project["id"], "Core")
    return vault, project, section


def test_no_delete_rule_constant_is_primary_product_law():
    assert "never deletes" in NO_DELETE_RULE
    assert "user-custodied material" in NO_DELETE_RULE


def test_no_delete_method_exists_and_candidate_copy_is_preserved():
    with tempfile.TemporaryDirectory() as tmpdir:
        vault, project, section = setup_vault(tmpdir)
        src = make_file("candidate")
        try:
            candidate = vault.add_candidate(project["id"], section["id"], str(src))
            vault_copy = Path(candidate["vault_path"])
            assert not hasattr(vault, "delete_file")
            assert vault_copy.is_file()
            assert candidate["state"] == "candidate"
        finally:
            src.unlink(missing_ok=True)


@pytest.mark.parametrize(
    ("method_name", "kwargs", "expected_error"),
    [
        ("remove_file", {}, "not yet migrated"),
        ("restore_file", {}, "not yet migrated"),
        ("quarantine_file", {"reason": "suspicious output"}, "transaction coordinator"),
        ("release_from_custody", {"human_confirmation": "RELEASE"}, "not yet migrated"),
    ],
)
def test_unavailable_direct_custody_transitions_fail_before_moving_or_deleting(
    method_name, kwargs, expected_error
):
    with tempfile.TemporaryDirectory() as tmpdir:
        vault, project, section = setup_vault(tmpdir)
        src = make_file("preserve me")
        try:
            candidate = vault.add_candidate(project["id"], section["id"], str(src))
            before_path = Path(candidate["vault_path"])
            before_state = candidate["state"]
            before_hash = candidate["hash"]
            method = getattr(vault, method_name)
            with pytest.raises(VaultError, match=expected_error):
                method(
                    project["id"], section["id"], candidate["id"],
                    "no-token-can-exist", session_id="no-session", **kwargs,
                )
            assert candidate["state"] == before_state
            assert candidate["vault_path"] == str(before_path)
            assert candidate["hash"] == before_hash
            assert before_path.is_file()
            assert not hasattr(vault, "delete_file")
            assert vault.list_ceremony_tokens() == []
        finally:
            src.unlink(missing_ok=True)
